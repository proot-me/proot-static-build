/* This file should define the POSIX options described in <unistd.h>,
   or leave them undefined, as appropriate.  */
