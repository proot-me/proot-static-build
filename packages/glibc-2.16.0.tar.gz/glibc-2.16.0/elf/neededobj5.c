extern void a1_function (void);

void a1_function (void)
{
}
