/* Test STT_GNU_IFUNC symbols with -fPIC.  */

#include "ifuncmain1.c"
