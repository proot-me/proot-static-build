PRoot documentation: doc/proot/manual.txt
CARE documentation: doc/care/manual.txt
